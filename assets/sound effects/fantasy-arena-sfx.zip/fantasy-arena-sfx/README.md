# Fantasy Arena SFX

by MCreative

35 sound effects for fantasy, RPG and arena games: fire and ice spells, shields, a phoenix and a dragon, sword clashes, bows, a charge horn and a trebuchet, plus arena crowds, rope and water.

35 sounds, 87 seconds of audio, including 4 seamless loops.

These sounds are also part of the bigger "Synthesised Casino & Arcade Sounds" pack. If you own that pack, you already have them.

## What's in the zip

    Audio/WAV/<NN_Category>/<Name>.wav   48 kHz, 24-bit PCM
    Audio/OGG/<NN_Category>/<Name>.ogg   48 kHz Ogg Vorbis, same sounds, smaller
    Screenshots/                         the store screenshots
    contact-sheet.png                    every sound with its waveform and length
    cover.png                            630 x 500 cover
    LICENSE.txt                          what you may and may not do
    README.md                            this file

## Specs

- Sample rate 48 kHz. WAV is 24-bit PCM. OGG is Vorbis at high quality.
- Levels are matched: loudness is -16 LUFS integrated, with true peaks at or
  below -1 dBTP. Short, punchy hits whose peaks reach -1 dBTP first sit a
  little quieter. Nothing clips, and levelling adds no limiter or compression.
- Files ending in `_Loop` loop seamlessly from the first sample to the last:
  set the whole file to loop, with no loop points to add.
- Every one-shot starts cleanly and fades out to true silence.
- Names are PascalCase with underscores, so they sort by category.

## Sounds

### Magic (14)

| File | Length | Channels |
|---|---:|---|
| Magic_Beam_Loop | 1.75 s | mono |
| Magic_Cast_Fire | 0.80 s | mono |
| Magic_Cast_Ice | 0.90 s | mono |
| Magic_Charge | 2.27 s | mono |
| Magic_Dragon | 2.20 s | mono |
| Magic_Freeze | 1.80 s | mono |
| Magic_Impact_Fire | 1.00 s | mono |
| Magic_Impact_Ice | 0.65 s | mono |
| Magic_Phoenix | 2.10 s | mono |
| Magic_Shatter | 1.25 s | mono |
| Magic_Shield | 0.83 s | mono |
| Magic_Thud | 0.60 s | mono |
| Magic_Whoosh | 0.57 s | mono |
| Magic_Wind_Loop | 10.50 s | mono |

### Battle (8)

| File | Length | Channels |
|---|---:|---|
| Battle_Banner_Plant | 1.50 s | mono |
| Battle_Bow_Release | 0.90 s | mono |
| Battle_Charge_Horn | 2.50 s | mono |
| Battle_Crowd_Cheer | 5.14 s | mono |
| Battle_Impact_Heavy | 1.50 s | mono |
| Battle_Sword_Clash | 3.00 s | mono |
| Battle_Thud | 0.80 s | mono |
| Battle_Trebuchet_Launch | 1.50 s | mono |

### Arena & Crowd (13)

| File | Length | Channels |
|---|---:|---|
| Arena_Confetti_Pop | 1.60 s | mono |
| Arena_Crowd_Chant_Loop | 8.00 s | mono |
| Arena_Power_Up | 2.00 s | mono |
| Arena_Roar | 4.00 s | mono |
| Arena_Rope_Creak_1 | 1.35 s | mono |
| Arena_Rope_Creak_2 | 1.40 s | mono |
| Arena_Rope_Taut | 0.72 s | mono |
| Arena_Skid | 0.47 s | mono |
| Arena_Slow_Motion | 2.52 s | mono |
| Arena_Splash | 2.05 s | mono |
| Arena_Victory | 5.00 s | mono |
| Arena_Waterfall_Loop | 12.00 s | mono |
| Arena_Whoosh | 1.44 s | mono |

## How it was made

Every sound was synthesised by our own code: oscillators, noise, filters and
envelopes, rendered offline. The code was written with the help of AI coding
tools. No samples, recordings, sound libraries or AI audio generators were used.

## Support

Questions or problems: leave a comment on the itch.io page.
